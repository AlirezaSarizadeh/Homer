// Product Cards
// jQuery(document).ready(function ($) {
//     $("#time1").soon().create({
//         due:"2022-09-21",
//         separator: ":",
//         layout: "group"
//       });
      
// });
/*!
 * aksCountDown v1.0.0
 * (c) 2021 Ahmet Aksungur
 * MIT License
 * https://github.com/Ahmetaksungur
 */
    if (matchMedia('only screen and (max-width: 767.99px)').matches) {
  $(".set > span").on("click", function () {
    if ($(this).hasClass('active')) {
      $(this).removeClass("active");
      $(this).siblings('.content').slideUp(200);
      $(".set > span i").removeClass("fas fa-chevron-up").addClass("fas fa-chevron-up");
    } else {
      $(".set > span i").removeClass("fas fa-chevron-up").addClass("fas fa-chevron-up");
      $(this).find("i").removeClass("fas fa-chevron-down").addClass("fas fa-chevron-up");
      $(".set > span").removeClass("active");
      $(this).addClass("active");
      $('.content').slideUp(200);
      $(this).siblings('.content').slideDown(200);
    }

  });
}
(function ($) {
    "use strict";
    $.fn.aksCountDown = function (options) {
      const aks = $(this);
      var settings = $.extend(
        {
          endTime: "",
          refresh: 1000,
          onEnd: function () {}
        },
        options
      );
      return this.each(function (i) {
        function endTimeCheck(d1, d2) {
          return (
            d1.getFullYear() === d2.getFullYear() &&
            d1.getMonth() === d2.getMonth() &&
            d1.getDate() === d2.getDate()
          );
        }
        function countTimer() {
          var endTime = new Date(settings.endTime);
          endTime = Date.parse(endTime) / 1000;
  
          var now = new Date();
          now = Date.parse(now) / 1000;
  
          var timeLeft = endTime - now;
  
          var days = Math.floor(timeLeft / 86400);
          var hours = Math.floor((timeLeft - days * 86400) / 3600);
          var minutes = Math.floor((timeLeft - days * 86400 - hours * 3600) / 60);
          var seconds = Math.floor(
            timeLeft - days * 86400 - hours * 3600 - minutes * 60
          );
  
          if (hours < "10") {
            hours = "0" + hours;
          }
          if (minutes < "10") {
            minutes = "0" + minutes;
          }
          if (seconds < "10") {
            seconds = "0" + seconds;
          }
  
          $(aks).find("[data-days]").html(days);
          $(aks).find("[data-hours]").html(hours);
          $(aks).find("[data-minutes]").html(minutes);
          $(aks).find("[data-seconds]").html(seconds);
        }
        var now = new Date();
        var endTime = new Date(settings.endTime);
  
        if (endTimeCheck(now, endTime) === true) {
          settings.onEnd.call(aks);
        } else {
          setInterval(function () {
            countTimer();
          }, settings.refresh);
        }
      });
    };
  })(jQuery);
  
  $("#timer").aksCountDown({
    endTime: "15 June 2022 9:56:00 GMT+01:00",
    onEnd: function () {
      $(this).html('<div class="timer-end">Finished Time</div>');
    }
  });
  
$('.slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: true,
    asNavFor: '.slider-nav'
});
$('.slider-nav').slick({
    slidesToShow:   5,
    slidesToScroll: 1,
    vertical:true,
    asNavFor: '.slider-for',
    dots: false,
    focusOnSelect: true,
    verticalSwiping:true,
    responsive: [
    {
        breakpoint: 992,
        settings: {
          vertical: false,
        }
    },
    {
      breakpoint: 768,
      settings: {
        vertical: false,
      }
    },
    {
      breakpoint: 580,
      settings: {
        vertical: false,
        slidesToShow: 1,
      }
    },
    {
      breakpoint: 380,
      settings: {
        vertical: false,
        slidesToShow: 1,
      }
    }
    ]
});
 
$('.card .aFavs').click(function(){
    $(this).parents('.card').toggleClass('esFav');
  })
  //Producto al carrito
  $('.card .alCarrito').click(function(){
    $(this).parents('.card').toggleClass('enCarrito');
})

// Carousels Started
$('.intro-carousel').owlCarousel({
    loop:true,
    rtl:true,
    autoplay:true,
    loop:true,
    margin:10,
    nav:true,
    dots:false,
    navText : ["<i class='fa fa-chevron-right fa-2x text-white'></i>","<i class='fa fa-chevron-left fa-2x text-white'></i>"],
    responsive:{
        0:{
            items:1
        }
    }
})
$('.popular-carousel').owlCarousel({
    loop:true,
    rtl:true,
    autoplay:true,
    loop:true,
    margin:15,
    nav:true,
    dots:false,
    navText : ["<i class='fa fa-arrow-right'></i>","<i class='fa fa-arrow-left'></i>"],
    responsive:{
        0:{
            items:1
        },
        768:{
            items:3
        },
        1100:{
            items:5
        }
    }
})
$('.mates-carousel').owlCarousel({
    loop:true,
    rtl:true,
    autoplay:true,
    loop:true,
    margin:0,
    nav:false,
    dots:false,
    responsive:{
        0:{
            items:2
        },
        768:{
            items:4
        },
        1100:{
            items:6
        }
    }
})
// $('.offer-carousel').owlCarousel({
//     loop:true,
//     rtl:true,
//     autoplay:true,
//     loop:true,
//     vertical    :true,
//     margin:10,
//     nav:true,
//     dots:false,
//     responsive:{
//         0:{
//             items:2
//         },
//         768:{
//             items:4
//         },
//         1100:{
//             items:6
//         }
//     }
// })
const menu = document.querySelector('.menu');
const menuSection = menu.querySelector('.menu-section');
const menuArrow = menu.querySelector('.menu-mobile-arrow');
const menuClosed = menu.querySelector('.menu-mobile-close');
const menuToggle = document.querySelector('.menu-mobile-toggle');
const menuOverlay = document.querySelector('.overlay');
let subMenu;

menuSection.addEventListener('click', (e) => {
	if (!menu.classList.contains('active')) {
		return;
	}
	if (e.target.closest('.menu-item-has-children')) {
		const hasChildren = e.target.closest('.menu-item-has-children');
		showSubMenu(hasChildren);
	}
});

menuArrow.addEventListener('click', () => {
	hideSubMenu();
});

menuToggle.addEventListener('click', () => {
	toggleMenu();
});

menuClosed.addEventListener('click', () => {
	toggleMenu();
});

menuOverlay.addEventListener('click', () => {
	toggleMenu();
});

// Show & Hide Toggle Menu Function
function toggleMenu() {
	menu.classList.toggle('active');
	menuOverlay.classList.toggle('active');
}

// Show the Mobile Side Menu Function
function showSubMenu(hasChildren) {
	subMenu = hasChildren.querySelector('.menu-subs');
	subMenu.classList.add('active');
	subMenu.style.animation = 'slideLeft 0.5s ease forwards';
	const menuTitle = hasChildren.querySelector('i').parentNode.childNodes[0].textContent;
	menu.querySelector('.menu-mobile-title').innerHTML = menuTitle;
	menu.querySelector('.menu-mobile-header').classList.add('active');
}

// Hide the Mobile Side Menu Function
function hideSubMenu() {
	subMenu.style.animation = 'slideRight 0.5s ease forwards';
	setTimeout(() => {
		subMenu.classList.remove('active');
	}, 300);

	menu.querySelector('.menu-mobile-title').innerHTML = '';
	menu.querySelector('.menu-mobile-header').classList.remove('active');
}

// Windows Screen Resizes Function
window.onresize = function () {
	if (this.innerWidth > 991) {
		if (menu.classList.contains('active')) {
			toggleMenu();
		}
	}
};

